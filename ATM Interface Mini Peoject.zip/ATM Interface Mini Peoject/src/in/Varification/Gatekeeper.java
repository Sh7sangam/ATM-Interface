package in.Varification;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

import in.Bank.AccountHolder;

public class Gatekeeper 
{   
    public static void main(String[] args) 
    {
        // parse the user database 
        Map<String, User> user_map = Database.load();

        Scanner keyboard = new Scanner(System.in);

        System.out.println("**Welcome To Interface Bank*** \n");
        System.out.println("Enter Valid Username");
        String username = keyboard.nextLine();

        if(user_map.containsKey(username))
        {
           System.out.println("Enter password");
           String password = keyboard.nextLine();

           if (user_map.get(username).doesPasswordEqual(password)) {
        	   System.out.println("Login Success Enjoy");
        	   AccountHolder ah = new AccountHolder();
        	   ah.showMenu();
           } else {
               System.out.println("Incorrect password");
           }
        }
        else
        {
        	System.out.println("Login Failed!!! You have enter something umatched. Try Again...");
        }
    }}