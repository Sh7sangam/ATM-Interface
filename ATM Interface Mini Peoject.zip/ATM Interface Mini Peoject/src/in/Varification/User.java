package in.Varification;
public class User 
{
    public String username, password; 

    public User(String[] parts)
    {
        username = parts[0];
        password = parts[1];
    }
    public boolean doesPasswordEqual(String password) {
        return this.password.equals(password);
    }
}