package in.Bank;

import java.util.Scanner;

public class AccountHolder {

	int currentBalance;
	int TransactionHistory;

	public void customer() {
		showMenu();
	}

	void deposit(int amount) {
		if (amount != 0) {
			currentBalance = currentBalance + amount;
			TransactionHistory = amount;
		}
	}

	void withdraw(int amount) {
		if (currentBalance != 0 && currentBalance>= amount) {
			currentBalance = currentBalance - amount;
			TransactionHistory = -amount;
			System.out.println("Transaction successful");
		} else {
			System.out.println("Insufficient Funds ");
		}
	}

	void transfer(int amount) {
		if (currentBalance != 0 && currentBalance>= amount) {
			currentBalance = currentBalance - amount;
			TransactionHistory = -amount;
			System.out.println();
			System.out.println("Transaction successful");

		} else {
			System.out.println("Insufficient Funds ");
		}
	}

	void getTransactionHistory() {
		if (TransactionHistory > 0) {
			System.out.println("Deposited: " + TransactionHistory);
		} else if (TransactionHistory < 0) {
			System.out.println("Withdraw: " + Math.abs(TransactionHistory));
		} else if (TransactionHistory > 0) {
			System.out.println("Transfered: " + Math.abs(TransactionHistory));
		}

		else {
			System.out.println("No Transaction Occured");
		}
	}

	public void showMenu() {

		int option = 0;
		Scanner sc = new Scanner(System.in);

		System.out.println("** Welcome You have Successfully entered into bank interface **");

		System.out.println();

		do {
			System.out.println("1 : Check Your Balance");
			System.out.println("2 : Deposit");
			System.out.println("3 : Withdraw");
			System.out.println("4 : Transfer");
			System.out.println("5 : Transaction History");
			System.out.println("6 : Exit The System");
			System.out.println();
			System.out.print("PLEASE SELECT A OPTION :--> ");
			option = sc.nextInt();
			
			switch (option) {

			case 1:
				System.out.println("-------------------------------------------------------");
				System.out.println("Balance = " + currentBalance);
				System.out.println("-------------------------------------------------------");
				System.out.println("\n");
				break;

			case 2:
				System.out.println("-------------------------------------------------------");
				System.out.print("Enter an amount to deposit :-->");
				int amount = sc.nextInt();
				deposit(amount);
				System.out.println("Enter an amount to deposited :: "+amount);
				System.out.println("-------------------------------------------------------");

				System.out.println("\n");

				break;

			case 3:
				System.out.println("-------------------------------------------------------");
				System.out.print("Enter an amount to withdraw :--> ");
				int amount2 = sc.nextInt();
				withdraw(amount2);
				System.out.println("Enter an amount to withdraw :: "+amount2);
				System.out.println("-------------------------------------------------------");

				System.out.println("\n");

				break;

			case 4:
				System.out.println("-------------------------------------------------------");
				System.out.print("Enter an amount to Transfer :--> ");
				int amount3 = sc.nextInt();
				transfer(amount3);
				System.out.println("Enter an amount to Transfered :: "+amount3);
				System.out.println("-------------------------------------------------------");

				System.out.println("\n");

				break;

			case 5:
				System.out.println("-------------------------------------------------------");
				getTransactionHistory();
				System.out.println("-------------------------------------------------------");
				System.out.println("\n");
				break;

			case 6:
				System.out.println("Exit");
				break;

			default:
				System.out.println("Invalid Option!! Please Enter Correct Opton...");
				break;
			}
		} while (option != 6);
		System.out.println("Thank You for Using our Services.....!!");
	}
}
